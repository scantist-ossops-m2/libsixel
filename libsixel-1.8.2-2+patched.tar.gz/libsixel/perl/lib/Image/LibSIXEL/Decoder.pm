package Image::LibSIXEL::Decoder;
use Image::LibSIXEL;

1;

#ifndef LIBSIXEL_H
#define LIBSIXEL_H 1

#include "ruby.h"

#endif /* LIBSIXEL_H */

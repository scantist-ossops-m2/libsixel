module Libsixel
  VERSION = "0.0.2"
end

package Image::LibSIXEL::Encoder;
use Image::LibSIXEL;

1;
